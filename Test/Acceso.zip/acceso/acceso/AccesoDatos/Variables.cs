﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace Acceso.AccesoDatos
{
    class Variables
    {
        public static string variable1 = "";
        public static string variable2 = "";
        public static string Hermano = "";
        public static string observacionesAlumno = "";
        public static int IntentosAcceso = 0;
        public static string Nombre = "";
        public static string Apellidos = "";
        public static string FechaVencimiento = "";
        public static string FechaRecibo = "";
        public static string Producto = "";
        public static string Importe = "";
        public static string Interes = "";
        public static string DiasLimite = "";
        public static string IdAlumno = "";
        public static string RP = "";
        public static string RS = "";
        public static string EstadoRecibo = "";

        
    }
}
